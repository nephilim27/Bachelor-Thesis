export default function AboutUs() {
    return <h1>AboutUs</h1>
  }